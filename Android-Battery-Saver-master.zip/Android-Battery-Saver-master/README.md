# TCC

Undergrad dissertation project to assist Android to save battery by saving stages of the foreground app in the local DB. The information saved for each app consists of: brightness level and frequency of each CPU core. For each app that is loaded by the user, a new config is created or a previous one is loaded.
